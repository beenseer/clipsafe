package com.example.clipsafe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;

/** Постоянное уведомление с кнопкой «Выбрать клавиатуру». */
final class Notifier {
    private static final String CHANNEL = "keyboard_picker";
    private static final int NOTIFICATION_ID = 1;
    private static final String PREFS = "settings";
    private static final String KEY_ENABLED = "notification_enabled";

    private Notifier() {}

    static boolean isEnabled(Context c) {
        return prefs(c).getBoolean(KEY_ENABLED, true);
    }

    static void setEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) {
            show(c);
        } else {
            hide(c);
        }
    }

    static void show(Context c) {
        Context app = c.getApplicationContext();
        NotificationManager nm =
                (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) {
            return;
        }

        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "Кнопка выбора клавиатуры", NotificationManager.IMPORTANCE_LOW);
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);

        Intent intent = new Intent(app, PickerActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(
                app, 0, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(app, R.drawable.ic_keyboard),
                "Выбрать клавиатуру", pi).build();

        Notification n = new Notification.Builder(app, CHANNEL)
                .setSmallIcon(R.drawable.ic_keyboard)
                .setContentTitle("Выбрать клавиатуру")
                .setContentText("Нажмите, чтобы переключить клавиатуру")
                .setContentIntent(pi)
                .addAction(action)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .build();

        nm.notify(NOTIFICATION_ID, n);
    }

    static void hide(Context c) {
        NotificationManager nm = (NotificationManager)
                c.getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(NOTIFICATION_ID);
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
