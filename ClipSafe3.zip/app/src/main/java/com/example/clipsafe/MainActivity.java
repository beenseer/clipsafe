package com.example.clipsafe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Главный экран: инструкция, включение клавиатуры, список сохранённых фрагментов. */
public class MainActivity extends Activity {

    private static final int REQ_NOTIFICATIONS = 1;

    private ListView list;
    private TextView empty;
    private Button notifButton;
    private List<String> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(16);
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(pad, pad, pad, pad);

        TextView help = new TextView(this);
        help.setTextSize(15);
        help.setText("СОХРАНИТЬ: выделите текст в любом приложении, нажмите «Поделиться» "
                + "и выберите «Сохранить в память». В Chrome то же самое есть в меню "
                + "выделения (⋮).\n\n"
                + "ВСТАВИТЬ: коснитесь поля ввода, переключите клавиатуру на «Память текста» "
                + "и нажмите нужный фрагмент. Кнопка «К клавиатуре» возвращает обычную "
                + "клавиатуру.\n\n"
                + "ПЕРЕКЛЮЧЕНИЕ КЛАВИАТУРЫ: в шторке уведомлений есть кнопка «Выбрать "
                + "клавиатуру». Ещё можно добавить плитку «Выбор клавиатуры» в быстрые "
                + "настройки (шторка → значок карандаша).\n\n"
                + "Первый раз нажмите кнопку 1 и включите переключатель «Память текста».");
        header.addView(help);

        Button enable = new Button(this);
        enable.setAllCaps(false);
        enable.setText("1. Включить клавиатуру «Память текста»");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        header.addView(enable);

        Button pick = new Button(this);
        pick.setAllCaps(false);
        pick.setText("2. Выбрать клавиатуру");
        pick.setOnClickListener(v -> {
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showInputMethodPicker();
            }
        });
        header.addView(pick);

        notifButton = new Button(this);
        notifButton.setAllCaps(false);
        notifButton.setOnClickListener(v -> {
            Notifier.setEnabled(this, !Notifier.isEnabled(this));
            updateNotifButton();
        });
        header.addView(notifButton);

        EditText test = new EditText(this);
        test.setHint("Поле для проверки вставки");
        header.addView(test);

        Button clearAll = new Button(this);
        clearAll.setAllCaps(false);
        clearAll.setText("Очистить всё");
        clearAll.setOnClickListener(v -> confirmClear());
        header.addView(clearAll);

        empty = new TextView(this);
        empty.setTextSize(17);
        empty.setPadding(0, pad, 0, pad);
        empty.setText("Пока ничего не сохранено");
        header.addView(empty);

        list = new ListView(this);
        list.addHeaderView(header, null, false);
        setContentView(list);

        list.setOnItemClickListener((parent, view, position, id) ->
                showItem(position - list.getHeaderViewsCount()));

        requestNotificationPermissionIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        updateNotifButton();
        if (Notifier.isEnabled(this)) {
            Notifier.show(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_NOTIFICATIONS && Notifier.isEnabled(this)) {
            Notifier.show(this);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
    }

    private void updateNotifButton() {
        notifButton.setText(Notifier.isEnabled(this)
                ? "Кнопка в шторке уведомлений: включена (нажмите, чтобы выключить)"
                : "Кнопка в шторке уведомлений: выключена (нажмите, чтобы включить)");
    }

    private void refresh() {
        items = Store.load(this);
        List<String> labels = new ArrayList<>();
        for (String s : items) {
            labels.add(Store.preview(s));
        }
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showItem(final int position) {
        if (position < 0 || position >= items.size()) return;
        final String text = items.get(position);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setMessage(text)
                .setPositiveButton("Копировать в системный буфер", (d, w) -> {
                    try {
                        ClipboardManager cm =
                                (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("text", text));
                        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Системный буфер не отвечает",
                                Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Удалить", (d, w) -> {
                    Store.remove(this, position);
                    refresh();
                })
                .setNeutralButton("Закрыть", null)
                .show();
    }

    private void confirmClear() {
        if (items.isEmpty()) return;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setMessage("Удалить все сохранённые фрагменты?")
                .setPositiveButton("Удалить", (d, w) -> {
                    Store.clear(this);
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
