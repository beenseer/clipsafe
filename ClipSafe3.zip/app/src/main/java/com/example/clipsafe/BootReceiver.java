package com.example.clipsafe;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** После перезагрузки возвращает уведомление с кнопкой выбора клавиатуры. */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                && Notifier.isEnabled(context)) {
            Notifier.show(context);
        }
    }
}
