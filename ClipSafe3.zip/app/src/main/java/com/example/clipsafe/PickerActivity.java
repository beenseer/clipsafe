package com.example.clipsafe;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.inputmethod.InputMethodManager;

/**
 * Невидимая активность: открывает системное окно выбора клавиатуры и сразу закрывается.
 * Окно выбора можно показать только из приложения, у которого есть фокус, поэтому
 * кнопки в уведомлении и в быстрых настройках запускают именно эту активность.
 */
public class PickerActivity extends Activity {

    private boolean shown = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !shown) {
            shown = true;
            InputMethodManager imm =
                    (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showInputMethodPicker();
            }
            new Handler(Looper.getMainLooper()).postDelayed(this::finish, 300);
        }
    }
}
