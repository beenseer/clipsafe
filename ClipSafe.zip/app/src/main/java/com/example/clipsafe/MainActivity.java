package com.example.clipsafe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** Список сохранённых фрагментов: просмотр, удаление, копирование в системный буфер (по желанию). */
public class MainActivity extends Activity {

    private ListView list;
    private TextView empty;
    private List<String> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView help = new TextView(this);
        help.setTextSize(15);
        help.setText("Сохранить: выделите текст в любом приложении и выберите в меню "
                + "«Сохранить в память».\n\n"
                + "Вставить: в поле ввода выделите слово или символ и выберите "
                + "«Вставить из памяти». Выбранный фрагмент заменит выделение.\n\n"
                + "Если пунктов нет в меню, нажмите ⋮ или «Ещё» в панели выделения.");
        root.addView(help);

        empty = new TextView(this);
        empty.setTextSize(17);
        empty.setPadding(0, pad, 0, pad);
        empty.setText("Пока ничего не сохранено");
        root.addView(empty);

        list = new ListView(this);
        root.addView(list, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button clearAll = new Button(this);
        clearAll.setText("Очистить всё");
        clearAll.setOnClickListener(v -> confirmClear());
        root.addView(clearAll);

        setContentView(root);

        list.setOnItemClickListener((parent, view, position, id) -> showItem(position));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        items = Store.load(this);
        List<String> labels = new ArrayList<>();
        for (String s : items) {
            labels.add(Store.preview(s));
        }
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels));
        empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void showItem(final int position) {
        if (position < 0 || position >= items.size()) return;
        final String text = items.get(position);

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setMessage(text)
                .setPositiveButton("Копировать в системный буфер", (d, w) -> {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("text", text));
                        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(this, "Системный буфер не отвечает", Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Удалить", (d, w) -> {
                    Store.remove(this, position);
                    refresh();
                })
                .setNeutralButton("Закрыть", null)
                .show();
    }

    private void confirmClear() {
        if (items.isEmpty()) return;
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setMessage("Удалить все сохранённые фрагменты?")
                .setPositiveButton("Удалить", (d, w) -> {
                    Store.clear(this);
                    refresh();
                })
                .setNegativeButton("Отмена", null)
                .show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
