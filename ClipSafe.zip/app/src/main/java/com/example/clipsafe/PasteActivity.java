package com.example.clipsafe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

/**
 * Вызывается из меню выделения в поле ввода. Показывает список сохранённого и
 * возвращает выбранный текст системе: он заменяет выделение. Системный буфер не нужен.
 */
public class PasteActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean readOnly = getIntent().getBooleanExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, false);
        if (readOnly) {
            Toast.makeText(getApplicationContext(),
                    "Сюда нельзя вставить: поле только для чтения", Toast.LENGTH_LONG).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        final List<String> items = Store.load(this);
        if (items.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Память пуста", Toast.LENGTH_SHORT).show();
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        String[] labels = new String[items.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = Store.preview(items.get(i));
        }

        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle("Вставить вместо выделенного")
                .setItems(labels, (dialog, which) -> {
                    Intent result = new Intent();
                    result.putExtra(Intent.EXTRA_PROCESS_TEXT, items.get(which));
                    setResult(RESULT_OK, result);
                    finish();
                })
                .setOnCancelListener(dialog -> {
                    setResult(RESULT_CANCELED);
                    finish();
                })
                .show();
    }
}
