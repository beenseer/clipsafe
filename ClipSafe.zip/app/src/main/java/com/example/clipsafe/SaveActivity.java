package com.example.clipsafe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/** Вызывается из меню выделения текста. Сохраняет выделенное и сразу закрывается. */
public class SaveActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CharSequence text = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        if (text != null && text.toString().trim().length() > 0) {
            Store.add(this, text.toString());
            Toast.makeText(getApplicationContext(), "Сохранено в память", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "Нечего сохранять", Toast.LENGTH_SHORT).show();
        }

        setResult(RESULT_CANCELED);
        finish();
    }
}
