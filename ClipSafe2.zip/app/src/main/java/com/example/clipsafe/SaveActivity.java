package com.example.clipsafe;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

/**
 * Принимает текст из «Поделиться» (ACTION_SEND) или из меню выделения (PROCESS_TEXT),
 * сохраняет его в память приложения и сразу закрывается.
 */
public class SaveActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent in = getIntent();
        CharSequence text;
        if (Intent.ACTION_SEND.equals(in.getAction())) {
            text = in.getCharSequenceExtra(Intent.EXTRA_TEXT);
        } else {
            text = in.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        }

        if (text != null && text.toString().trim().length() > 0) {
            Store.add(this, text.toString());
            Toast.makeText(getApplicationContext(), "Сохранено в память", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getApplicationContext(), "Нечего сохранять", Toast.LENGTH_SHORT).show();
        }

        setResult(RESULT_CANCELED);
        finish();
    }
}
