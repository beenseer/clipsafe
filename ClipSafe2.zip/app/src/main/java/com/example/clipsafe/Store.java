package com.example.clipsafe;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** Собственное хранилище приложения. Системный буфер обмена не используется. */
final class Store {
    private static final String PREFS = "clips";
    private static final String KEY = "items";
    private static final int MAX_ITEMS = 300;

    private Store() {}

    static List<String> load(Context c) {
        List<String> out = new ArrayList<>();
        String raw = prefs(c).getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                out.add(arr.getString(i));
            }
        } catch (JSONException ignored) {
            // повреждённые данные считаем пустым списком
        }
        return out;
    }

    /** Новый фрагмент ставится первым; повтор того же текста не плодит дубликатов. */
    static void add(Context c, String text) {
        List<String> items = load(c);
        items.remove(text);
        items.add(0, text);
        while (items.size() > MAX_ITEMS) {
            items.remove(items.size() - 1);
        }
        save(c, items);
    }

    static void remove(Context c, int index) {
        List<String> items = load(c);
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            save(c, items);
        }
    }

    static void clear(Context c) {
        save(c, new ArrayList<String>());
    }

    private static void save(Context c, List<String> items) {
        JSONArray arr = new JSONArray();
        for (String s : items) {
            arr.put(s);
        }
        prefs(c).edit().putString(KEY, arr.toString()).apply();
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Короткая строка для списков: без переносов, с обрезкой. */
    static String preview(String s) {
        String one = s.replace('\n', ' ').replace('\r', ' ').trim();
        return one.length() > 90 ? one.substring(0, 90) + "…" : one;
    }
}
