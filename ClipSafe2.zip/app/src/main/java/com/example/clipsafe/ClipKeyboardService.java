package com.example.clipsafe;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/**
 * Клавиатура-«память»: показывает сохранённые фрагменты и вставляет выбранный
 * прямо в поле ввода через InputConnection. Системный буфер обмена не используется.
 */
public class ClipKeyboardService extends InputMethodService {

    private static final int PER_PAGE = 5;

    private LinearLayout clipsBox;
    private TextView pageLabel;
    private int page = 0;

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        int p = dp(6);
        root.setPadding(p, p, p, p);

        // Верхний ряд: возврат к обычной клавиатуре и сохранение выделенного из поля
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.addView(makeButton("К клавиатуре", v -> switchBack()), lp(0, 2f));
        top.addView(makeButton("Сохранить выделенное", v -> saveSelected()), lp(0, 3f));
        root.addView(top);

        // Второй ряд: базовые клавиши
        LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        keys.addView(makeButton("Пробел", v -> commit(" ")), lp(0, 2f));
        keys.addView(makeButton("Стереть", v -> sendKey(KeyEvent.KEYCODE_DEL)), lp(0, 2f));
        keys.addView(makeButton("Ввод", v -> sendKey(KeyEvent.KEYCODE_ENTER)), lp(0, 2f));
        root.addView(keys);

        clipsBox = new LinearLayout(this);
        clipsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(clipsBox);

        // Нижний ряд: листание страниц
        LinearLayout pager = new LinearLayout(this);
        pager.setOrientation(LinearLayout.HORIZONTAL);
        pager.addView(makeButton("<", v -> { page--; refresh(); }), lp(0, 1f));
        pageLabel = new TextView(this);
        pageLabel.setTextColor(Color.BLACK);
        pageLabel.setTextSize(16);
        pageLabel.setGravity(Gravity.CENTER);
        pager.addView(pageLabel, lp(0, 2f));
        pager.addView(makeButton(">", v -> { page++; refresh(); }), lp(0, 1f));
        root.addView(pager);

        refresh();
        return root;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        page = 0;
        if (clipsBox != null) {
            refresh();
        }
    }

    private void refresh() {
        List<String> items = Store.load(this);
        int pages = Math.max(1, (items.size() + PER_PAGE - 1) / PER_PAGE);
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;

        clipsBox.removeAllViews();

        if (items.isEmpty()) {
            TextView msg = new TextView(this);
            msg.setTextColor(Color.BLACK);
            msg.setTextSize(16);
            msg.setGravity(Gravity.CENTER);
            msg.setText("Память пуста.\nСохраняйте текст через «Поделиться».");
            clipsBox.addView(msg, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(52) * PER_PAGE));
        } else {
            for (int i = 0; i < PER_PAGE; i++) {
                int idx = page * PER_PAGE + i;
                if (idx < items.size()) {
                    final String full = items.get(idx);
                    Button b = makeButton(Store.preview(full), v -> commit(full));
                    b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                    b.setSingleLine(true);
                    b.setEllipsize(TextUtils.TruncateAt.END);
                    clipsBox.addView(b, lp(LinearLayout.LayoutParams.MATCH_PARENT, 0f));
                } else {
                    // пустая строка, чтобы высота клавиатуры не прыгала между страницами
                    clipsBox.addView(new View(this), lp(LinearLayout.LayoutParams.MATCH_PARENT, 0f));
                }
            }
        }

        pageLabel.setText("Стр. " + (page + 1) + " из " + pages);
    }

    private void commit(String text) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.commitText(text, 1);
        }
    }

    private void sendKey(int keyCode) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, keyCode));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, keyCode));
    }

    private void saveSelected() {
        InputConnection ic = getCurrentInputConnection();
        CharSequence sel = (ic == null) ? null : ic.getSelectedText(0);
        if (sel != null && sel.toString().trim().length() > 0) {
            Store.add(this, sel.toString());
            page = 0;
            refresh();
            Toast.makeText(this, "Сохранено в память", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Сначала выделите текст в поле ввода", Toast.LENGTH_LONG).show();
        }
    }

    private void switchBack() {
        boolean ok = false;
        try {
            ok = switchToPreviousInputMethod();
        } catch (Throwable ignored) {
            // перейдём к запасному варианту ниже
        }
        if (!ok) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showInputMethodPicker();
            }
        }
    }

    private Button makeButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.BLACK);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setStroke(dp(2), Color.BLACK);
        bg.setCornerRadius(dp(6));
        b.setBackground(bg);
        b.setOnClickListener(listener);
        return b;
    }

    private LinearLayout.LayoutParams lp(int width, float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, dp(48), weight);
        p.setMargins(dp(2), dp(2), dp(2), dp(2));
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
